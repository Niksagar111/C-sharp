﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication10
{
    
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter Your Actual Age:");
            int age = Convert.ToInt32(Console.ReadLine());
            if (age > 0)
            {
                if (age >= 18 && age < 60)
                {

                    Console.Write("Adult");
                }
                else if (age < 18)
                {
                    Console.Write("Teenage");
                }
                else if (age >= 60)
                {
                    Console.Write("Senior Citizen");
                }
            }
            else
            {
                Console.Write("Brith Panding");
            }
            Console.Read();
        }
    }
}

     