﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(String[] args)
        {
            
            Console.Clear();

            int n1, n2, s1, s2, s3, s4;
            Console.Write("Enter Number n1:");
            n1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Number n2:");
            n2 = Convert.ToInt32(Console.ReadLine());
            s1 = n1 + n2;
            s2 = n1 - n2;
            s3 = n1 * n2;
            s4 = n1 / n2;

            Console.WriteLine("Sum is:" + s1);
            Console.WriteLine("sub is:" + s2);
            Console.WriteLine("min is:" + s3);
            Console.WriteLine("div is:" + s4);
            Console.ReadLine();

        }
    }
}
