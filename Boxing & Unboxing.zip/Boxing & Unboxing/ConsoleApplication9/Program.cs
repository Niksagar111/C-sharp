﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication9
{
    class Program
    {
        static void Main(string[] args)
        {
            //Boxing & unboxing code
            int i = 10;
            object obj = i;//boxing "value to int"
            Console.WriteLine(obj);
            int j = (int)obj;//unboxing " int to value "
            Console.Write(j);
            Console.Read();



        }
    }
}
