﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication6
{
    class Program
    {
        static void Main(string[] args)
        {
            int A, B, C, s1, s2, s3, s4, s5 ,s6 , s7;
            Console.Write("Enter Number:");
            A = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Number:");
            B = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Number:");
            C = Convert.ToInt32(Console.ReadLine());
            s1 = A + B - C;
            s2 = A + B * (B - C) / A + C;
            s3 = A / B + C * (A * B);
            s4 = A - B - C;
            s5 = A * B / C;
            s6 = C / A + (B - C) * A;
            s7 = A + B + (C + A / B) * A + B;
            Console.WriteLine("-----------------------");
            Console.WriteLine("A+B-C          :" + s1);
            Console.WriteLine("-----------------------");
            Console.WriteLine("A+B*(B-C)/A+C  :" + s2);
            Console.WriteLine("-----------------------");
            Console.WriteLine("A/B+C*(A*B)    :" + s3);
            Console.WriteLine("-----------------------");
            Console.WriteLine("A-B-C          :" + s4);
            Console.WriteLine("-----------------------");
            Console.WriteLine("A*B/C          :" + s5);
            Console.WriteLine("-----------------------");
            Console.WriteLine("C/A+(B-C)*A    :" + s6);
            Console.WriteLine("-----------------------");
            Console.WriteLine("A+B+(C+A/B)*A+B:" + s7);
            Console.WriteLine("-----------------------");       
            Console.ReadLine();

            
        }
    }
}
