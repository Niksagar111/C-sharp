﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication5
{
    class Program
    {
        static void     Main(string[] args)
        {
            Console.BackgroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.Black;
            Console.Clear();

            int n1, n2, s1, s2, s3, s4;
            Console.Write("Enter Number n1:");
            n1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Number n2:");
            n2 = Convert.ToInt32(Console.ReadLine());
            s1 = n1 + n2;
            s2 = n1 - n2;
            s3 = n1 * n2;
            s4 = n1 / n2;
            Console.Write("sum is " + s1);
            Console.Write("sub is" + s2);
            Console.Write("mul is" + s3);
            Console.Write("div is" + s4);
            Console.ReadLine();


        }
    }
}
